# Snap Wave

An original dark-purple social communication app prototype designed for mobile screens.

## Included
- Welcome screen with Log In and Create Account modes
- Basic form validation and a demo-only session in the browser
- Chat list with search and local sample conversations
- Stories row and camera/photo picker preview
- Calls and profile screens
- Responsive layout for phones

## Run on your Android phone
1. Download and extract this project ZIP.
2. Open `index.html` using a mobile browser or a local HTML preview app.
3. For a hosted preview, upload `index.html`, `styles.css`, and `app.js` to a static hosting service.

## Important limitations
This is a front-end prototype. The login/register flow is not secure authentication and does not create accounts on a server. Chat messages stay in the current browser dialog and are not delivered to other people. Calls, friend search, online stories, password recovery, and real accounts require a backend and suitable messaging/calling services.

## Next steps toward production
- Add a trusted authentication provider and server-side authorization.
- Store passwords only with a secure auth provider; never store plaintext passwords.
- Add a database, access rules, reporting/blocking, and privacy controls.
- Add a real-time messaging service and WebRTC/calling provider.
- Test privacy, abuse prevention, and account recovery before public launch.
